<?php
Class Dbconn {
    protected $servername = "localhost";
    protected $dbname     = "comprof";
    protected $username   = "root";
    protected $password   = "root";

    
function cek_koneksi (){
    try{$conn =new PDO("mysql:host=$this->servername;dbname=$this->dbname", $this->username, $this->password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "connected to .. ".$this->dbname;
        }catch(PDOException $e){
            echo"Connection failed: ". $e->getMessage()."<br>";
            
        }
}
// fungsi untuk terkoneksi ke database dan menampilkan umpan balik berupa array

function dbresult($sql,$data=""){
    $servername =   "localhost";
    $dbname     =   "biodata";
    $username   =   "root";
    $password   =   "root";
    try{$conn =new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $res = $conn->prepare($sql);
    if ($data!=''){
               foreach ($data as $key => &$val) {
                    $key++;
                    $res->bindParam($key, $val);
												}
               }
        $res->execute();
               $conn = null;
        return $res;
    }catch(PDOException $e){
        echo"Connection failed: ". $e->getMessage()."<br>";
        
    }
    
    }
    
}
